  "bad addressing mode",ERROR,
  "bad register",ERROR,
  "pc-relative destination out of range: %ld (valid: %d..%d)",ERROR,
  "bad trap code %ld (valid: %d..%d)",ERROR,
  "displacement out of range: %ld",ERROR,
  "immediate value out of range: %ld",ERROR,                          /* 05 */
  "absolute address out of range: %ld",ERROR,
  "data size %d not supported",ERROR,
  "data expression doesn't fit into %d bits",ERROR,
