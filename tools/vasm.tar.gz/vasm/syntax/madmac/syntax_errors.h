  "malformed immediate-if",ERROR,
  "cannot export local symbol",ERROR,
  "no space before operands",WARNING,
  "too many closing parentheses",WARNING,
  "missing closing parentheses",WARNING,
  "missing operand",ERROR,                                           /* 5 */
  "garbage at end of line",WARNING,
  "unknown print format flag \'%c\'",WARNING,
  "invalid data operand",ERROR,
  "print format corrupted",ERROR,
  "identifier expected",ERROR,                                       /* 10 */
  "",WARNING,
  "unexpected \"%s\" without \"%s\"",ERROR,
